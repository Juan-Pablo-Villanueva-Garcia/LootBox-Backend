package com.lootbox.ecommercelb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EcommercelbApplication {

	public static void main(String[] args) {
		SpringApplication.run(EcommercelbApplication.class, args);
	}

}
