package com.lootbox.ecommercelb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EcommercelbApplicationTests {

	@Test
	void contextLoads() {
	}

}
